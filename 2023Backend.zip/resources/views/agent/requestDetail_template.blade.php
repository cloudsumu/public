@extends('agent.layout.app')

@section('title')
    User Request
@endsection

@include('admin.requestDetail')