<?php

return array (
  'subtitle' => '',
  'title' => '',
);
