<?php

return array (
  'FAQ' => '',
  'Legal' => '',
  'Privacy_Policy' => '',
  'Terms_&_Conditions' => '',
  'footer_intro' => '',
);
