<?php

return array (
  'logout_success' => 'Излезли сте успешно!',
  'push' => 
  array (
    'provider_status_hold' => 'Излезте офлайн, ако искате да си починете',
  ),
);
