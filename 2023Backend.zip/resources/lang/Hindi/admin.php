<?php

return array (
  'dispute' => 
  array (
    'new_dispute' => 'hi',
  ),
);
